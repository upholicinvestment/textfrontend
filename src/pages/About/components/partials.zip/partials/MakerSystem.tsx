import React, { useState } from 'react';
import { Cpu, Workflow, ShieldCheck, TrendingUp, Database, Activity, Zap } from "lucide-react";

const tiles = [
  { 
    icon: Cpu, 
    title: "Streaming Core", 
    body: "Tick bus with dedup, back-pressure & warm replay.",
    color: "from-blue-500 to-cyan-500",
    bgColor: "from-blue-50 to-cyan-50",
    borderColor: "border-blue-200"
  },
  { 
    icon: Workflow, 
    title: "Order Router", 
    body: "Multi-broker failover, throttling & full audit.",
    color: "from-purple-500 to-pink-500",
    bgColor: "from-purple-50 to-pink-50",
    borderColor: "border-purple-200"
  },
  { 
    icon: ShieldCheck, 
    title: "Risk Controls", 
    body: "SL/TP frameworks, circuit guards, soft/hard limits.",
    color: "from-emerald-500 to-teal-500",
    bgColor: "from-emerald-50 to-teal-50",
    borderColor: "border-emerald-200"
  },
  { 
    icon: TrendingUp, 
    title: "Strategy Runner", 
    body: "Signals → jobs → orders with dry-run & kill-switch.",
    color: "from-orange-500 to-red-500",
    bgColor: "from-orange-50 to-red-50",
    borderColor: "border-orange-200"
  },
  { 
    icon: Database, 
    title: "Journals & PnL", 
    body: "Auto-tags, notes and truthful timelines.",
    color: "from-indigo-500 to-purple-500",
    bgColor: "from-indigo-50 to-purple-50",
    borderColor: "border-indigo-200"
  },
  { 
    icon: Activity, 
    title: "Monitoring", 
    body: "Connectors, queues, webhooks health & status APIs.",
    color: "from-amber-500 to-orange-500",
    bgColor: "from-amber-50 to-orange-50",
    borderColor: "border-amber-200"
  },
];

export default function MakerSystem() {
  const [hoveredTile, setHoveredTile] = useState<number | null>(null);

  return (
    <div className="relative">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25px 25px, rgba(59, 130, 246, 0.3) 2px, transparent 0)`,
          backgroundSize: '50px 50px'
        }}></div>
      </div>

      {/* Header */}
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-full mb-4">
          <Zap className="w-4 h-4 text-blue-600" />
          <span className="text-sm font-semibold text-blue-700">System Architecture</span>
        </div>
        <h3 className="text-2xl font-bold text-slate-900 mb-2">Built for Performance</h3>
        <p className="text-slate-600">Enterprise-grade trading infrastructure components</p>
      </div>

      {/* Tiles Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {tiles.map((tile, index) => (
          <div
            key={index}
            className="group relative"
            onMouseEnter={() => setHoveredTile(index)}
            onMouseLeave={() => setHoveredTile(null)}
          >
            {/* Hover Glow Effect */}
            <div className={`absolute -inset-1 bg-gradient-to-r ${tile.color} rounded-2xl blur opacity-0 group-hover:opacity-20 transition-all duration-500`}></div>
            
            {/* Main Card */}
            <div className={`relative bg-white rounded-2xl border ${tile.borderColor} p-6 h-full transition-all duration-500 group-hover:scale-[1.02] group-hover:shadow-2xl group-hover:shadow-black/10 group-hover:border-opacity-50`}>
              {/* Background Gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${tile.bgColor} rounded-2xl opacity-0 group-hover:opacity-60 transition-opacity duration-500`}></div>
              
              {/* Shine Effect */}
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out overflow-hidden rounded-2xl">
                <div className="h-full w-6 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"></div>
              </div>

              {/* Content */}
              <div className="relative z-10">
                {/* Icon */}
                <div className={`inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br ${tile.color} text-white mb-4 group-hover:scale-110 transition-all duration-300 shadow-lg group-hover:shadow-xl`}>
                  <tile.icon size={22} />
                </div>

                {/* Title */}
                <h4 className="font-bold text-slate-900 mb-3 text-lg group-hover:text-slate-800 transition-colors">
                  {tile.title}
                </h4>

                {/* Description */}
                <p className="text-sm text-slate-600 leading-relaxed group-hover:text-slate-700 transition-colors">
                  {tile.body}
                </p>

                {/* Status Indicator */}
                <div className="flex items-center gap-2 mt-4 opacity-0 group-hover:opacity-100 transition-all duration-500 delay-200">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs font-medium text-green-600">Active</span>
                  <div className="ml-auto">
                    <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center">
                      <div className="w-2 h-2 bg-slate-400 rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Corner Accent */}
              <div className={`absolute top-0 right-0 w-0 h-0 border-l-[20px] border-b-[20px] border-l-transparent border-b-gradient-to-br ${tile.color} rounded-tr-2xl opacity-0 group-hover:opacity-20 transition-opacity duration-500`}></div>
            </div>
          </div>
        ))}
      </div>

      {/* Connection Lines (visible on larger screens) */}
      <div className="hidden lg:block absolute inset-0 pointer-events-none">
        {/* Subtle connecting lines between related components */}
        <svg className="w-full h-full opacity-10">
          <defs>
            <linearGradient id="connectionGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3B82F6" />
              <stop offset="100%" stopColor="#8B5CF6" />
            </linearGradient>
          </defs>
          <path 
            d="M 200 150 Q 300 200 400 150" 
            stroke="url(#connectionGradient)" 
            strokeWidth="2" 
            fill="none"
            className={`transition-opacity duration-1000 ${hoveredTile !== null ? 'opacity-30' : 'opacity-0'}`}
          />
        </svg>
      </div>
    </div>
  );
}