import React from "react";
import { motion } from "framer-motion";
import { Handshake, Compass, Diamond, Zap } from "lucide-react";

const items = [
  {
    n: "01",
    h: "Ownership",
    b: "You design it, ship it, observe it, improve it.",
    Icon: Handshake,
    grad: "from-fuchsia-500 via-pink-500 to-rose-500",
  },
  {
    n: "02",
    h: "Clarity",
    b: "Simple APIs, simple UIs, simple runbooks.",
    Icon: Compass,
    grad: "from-sky-500 via-cyan-500 to-teal-400",
  },
  {
    n: "03",
    h: "Quality",
    b: "Readable code, delightful UI, trustworthy data.",
    Icon: Diamond,
    grad: "from-amber-500 via-orange-500 to-red-500",
  },
  {
    n: "04",
    h: "Speed",
    b: "Short cycles, measurable wins, boring incidents.",
    Icon: Zap,
    grad: "from-violet-500 via-indigo-500 to-blue-500",
  },
];

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08, delayChildren: 0.05 } },
};

const card = {
  hidden: { y: 10, opacity: 0 },
  show: { y: 0, opacity: 1 },
};

export default function ValuesGrid() {
  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"
    >
      {items.map(({ n, h, b, Icon, grad }) => (
        <motion.div key={n} variants={card} whileHover={{ scale: 1.02, rotate: 0.25 }}>
          {/* Gradient border wrapper */}
          <div
            className={`group relative rounded-2xl p-[1.5px] bg-gradient-to-br ${grad} shadow-lg shadow-black/5`}
          >
            {/* Card body (glass) */}
            <div className="relative rounded-2xl bg-white/75 dark:bg-slate-900/70 backdrop-blur-xl p-5 ring-1 ring-white/40 dark:ring-white/10 overflow-hidden">
              {/* Shine sweep */}
              <span className="pointer-events-none absolute inset-0 -translate-x-1/2 opacity-0 group-hover:opacity-10 group-hover:translate-x-0 transition duration-700 bg-[radial-gradient(60%_60%_at_10%_0%,white,transparent)]" />

              {/* Number chip */}
              <div className="absolute -top-3 -right-3">
                <div className={`rounded-xl px-3 py-1 text-[11px] font-bold text-white bg-gradient-to-r ${grad} shadow-md`}>
                  {n}
                </div>
              </div>

              <div className="flex items-start gap-4">
                {/* Icon bubble */}
                <div className="relative">
                  <div className="h-12 w-12 grid place-items-center rounded-xl bg-white/80 dark:bg-white/5 ring-1 ring-black/5 dark:ring-white/10 backdrop-blur-md">
                    <Icon className="h-6 w-6 opacity-80 group-hover:opacity-100 transition-transform duration-300 group-hover:scale-110" />
                  </div>
                  {/* glow */}
                  <div className={`absolute inset-0 -z-10 blur-xl opacity-20 group-hover:opacity-40 transition bg-gradient-to-br ${grad}`} />
                </div>

                <div className="space-y-1.5">
                  <div className={`text-base font-semibold bg-gradient-to-r ${grad} bg-clip-text text-transparent`}>
                    {h}
                  </div>
                  <div className="text-sm text-slate-600 dark:text-slate-300/80 leading-relaxed">
                    {b}
                  </div>
                </div>
              </div>

              {/* Bottom accent line */}
              <div className={`mt-4 h-[2px] w-full rounded-full bg-gradient-to-r ${grad} opacity-40 group-hover:opacity-100 transition`} />
            </div>

            {/* Ambient ring on hover */}
            <div className={`pointer-events-none absolute -inset-0.5 rounded-2xl blur-lg opacity-0 group-hover:opacity-40 transition bg-gradient-to-br ${grad}`} />
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
}
