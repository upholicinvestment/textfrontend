import RoleCard from "../ui/RoleCard";

type Props = { selectedTrack: string; className?: string };

const roles = [
  { track: "Developers",          title: "Frontend Engineer (React)",          tags: ["React","WebSockets","Charts"],                blurb: "Own live UIs: ladders, blotters, analytics. Performance & accessibility focused." },
  { track: "Developers",          title: "Backend Engineer (Node/Python)",     tags: ["Node","Python","Queues","APIs"],              blurb: "Design resilient services for streaming, routing, auditing & monitoring." },
  { track: "Developers",          title: "Mobile Engineer (React Native)",     tags: ["RN","Realtime","Push"],                       blurb: "Bring Upholic to pockets — clean, fast, reliable." },
  { track: "Trading Consultants", title: "Options Trading Consultant",          tags: ["Options","Risk","Client Success"],            blurb: "Guide users on execution best-practices, risk frameworks and platform workflows." },
  { track: "Telecallers",         title: "Telecaller – Customer Success",      tags: ["Hindi/English","Empathy","CRM"],              blurb: "Proactive outreach, onboarding help, capturing feedback and resolving issues." },
  { track: "DevOps / SRE",        title: "Site Reliability Engineer",          tags: ["K8s","Observability","Automation"],           blurb: "Keep incidents boring: infra as code, monitoring, backups and drills." },
  { track: "Growth & Partnerships", title: "Partner Manager",                   tags: ["B2B","APIs","Enablement"],                    blurb: "Own creator/desk relationships. Co-build solutions, measure outcomes." },
  { track: "Operations",          title: "Customer Ops Specialist",            tags: ["SOPs","QA","Coordination"],                   blurb: "Triage, quality checks, and smooth operations across teams." },
];

export default function RoleListings({ selectedTrack, className }: Props) {
  const filtered = roles.filter(
    (r) => selectedTrack === "All" || r.track === selectedTrack
  );

  return (
    <div className={`grid gap-6 lg:grid-cols-2 ${className || ""}`}>
      {filtered.map((r, i) => (
        <RoleCard key={i} role={r} />
      ))}
    </div>
  );
}
