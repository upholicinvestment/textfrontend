import SectionHeading from "../ui/SectionHeading";
import TimelineCard from "../ui/TimelineCard";

const data = [
  { year: "2008", title: "Origins",       body: "Weekend projects for discretionary traders — screeners, alerts and a scrappy journal." },
  { year: "2016", title: "Infra-first",   body: "Low-latency websockets, queues, and auditability across brokers." },
  { year: "2021", title: "Automation",    body: "Signals → orders with guard-rails. Limits, journaling, status pages." },
  { year: "2023", title: "Creator stack", body: "Templates & safe distribution for educators and desks." },
  { year: "Now",  title: "Edge at scale", body: "Calm, reliable trading systems powering thousands of daily decisions." },
];

export default function Timeline() {
  const GRAD = "from-[#1a237e] to-[#4a56d2]";
  return (
    <section className="px-6 py-16 md:py-24">
      <div className="mx-auto max-w-7xl">
        <SectionHeading title="A timeline built in public" subtitle="Milestones that shaped how traders use Upholic" />

        <div className="flex snap-x snap-mandatory items-center gap-0 overflow-x-auto pb-4 lg:justify-between lg:gap-6 lg:overflow-visible">
          {data.map((t, i) => (
            <div key={t.year} className="flex items-center">
              <TimelineCard {...t} />
              {i !== data.length - 1 && (
                <div className={`mx-3 hidden h-1 w-14 rounded-full bg-gradient-to-r ${GRAD} lg:block`} />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
