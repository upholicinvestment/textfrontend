import { Code2, LineChart, PhoneCall, Server, Users, Briefcase } from "lucide-react";

type Props = { value: string; onChange: (v: string) => void };

export const tracks = [
  { key: "Developers",           icon: Code2 },
  { key: "Trading Consultants",  icon: LineChart },
  { key: "Telecallers",          icon: PhoneCall },
  { key: "DevOps / SRE",         icon: Server },
  { key: "Growth & Partnerships",icon: Users },
  { key: "Operations",           icon: Briefcase },
];

export default function CareerTracks({ value, onChange }: Props) {
  const all = ["All", ...tracks.map((t) => t.key)];
  const GRAD = "from-[#1a237e] to-[#4a56d2]";

  return (
    <div className="mb-6">
      <div className="flex flex-wrap items-center gap-2">
        {all.map((t) => (
          <button
            key={t}
            onClick={() => onChange(t)}
            className={`rounded-full border px-3.5 py-1.5 text-sm transition ${
              value === t
                ? `border-transparent bg-gradient-to-r ${GRAD} text-white`
                : "border-slate-200 bg-white hover:bg-slate-50"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* legend */}
      <div className="mt-3 flex flex-wrap gap-3">
        {tracks.map((t) => (
          <span key={t.key} className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600">
            <t.icon size={14} /> {t.key}
          </span>
        ))}
      </div>
    </div>
  );
}
