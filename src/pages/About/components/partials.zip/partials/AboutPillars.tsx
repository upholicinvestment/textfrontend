// src/pages/About/components/partials/AboutPillars.tsx
import React, { useEffect, useRef, useState } from "react";

type SlideInImageProps = {
  src: string;
  alt: string;
  direction?: "left" | "right";
  className?: string;
};

function SlideInImage({ src, alt, direction = "left", className = "" }: SlideInImageProps) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setVisible(true)),
      { root: null, rootMargin: "0px", threshold: 0.25 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const base =
    "overflow-hidden rounded-xl ring-1 ring-black/5 shadow-sm bg-gray-100 h-full";
  const motion =
    "transition-all duration-700 ease-out will-change-transform";
  const start =
    direction === "left" ? "-translate-x-10 opacity-0" : "translate-x-10 opacity-0";
  const end = "translate-x-0 opacity-100";

  return (
    <div ref={ref} className={`${base} ${motion} ${visible ? end : start} ${className}`}>
      {/* Image wrapper keeps aspect on all screens */}
      <img
        src={src}
        alt={alt}
        className="h-full w-full object-cover"
        loading="lazy"
      />
    </div>
  );
}

type AboutPillarsProps = {
  leftImage?: string;
  rightImage?: string;
};

export default function AboutPillars({
  leftImage = "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=1600&auto=format&fit=crop",
  rightImage = "https://images.unsplash.com/photo-1529336953121-ad5a0d43d0d2?q=80&w=1600&auto=format&fit=crop",
}: AboutPillarsProps) {
  return (
    <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-10">
      {/* Card 1 — Mission */}
      <article className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        <SlideInImage
          src={leftImage}
          alt="Engineers reviewing trading dashboards"
          direction="left"
          className="min-h-[220px]"
        />

        <div className="bg-white rounded-2xl ring-1 ring-black/5 shadow-sm p-6 sm:p-8 flex flex-col justify-between">
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-wider text-gray-500">OUR MISSION</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-gray-900">
              Empowering Profitable, Safe, Hands-Off Trading
            </h3>
            <p className="text-gray-600 leading-relaxed">
              We build an end-to-end stack—market data firehose, strategy runner, risk &
              execution, and truthful analytics—so traders ship ideas to production with
              prop-desk grade speed, transparency, and control.
            </p>

            <ul className="mt-3 space-y-2 text-gray-700">
              <li className="flex gap-2">
                <span className="mt-1 h-2 w-2 rounded-full bg-indigo-500"></span>
                <span>Real-time tick bus with de-dup, back-pressure & warm replay.</span>
              </li>
              <li className="flex gap-2">
                <span className="mt-1 h-2 w-2 rounded-full bg-indigo-500"></span>
                <span>Strategy Runner (Python / Pine / JS) — dry-run → paper → live.</span>
              </li>
              <li className="flex gap-2">
                <span className="mt-1 h-2 w-2 rounded-full bg-indigo-500"></span>
                <span>Risk engine: SL/TP frameworks, circuit guards, daily loss limits.</span>
              </li>
              <li className="flex gap-2">
                <span className="mt-1 h-2 w-2 rounded-full bg-indigo-500"></span>
                <span>Broker integrations: Angel, Zerodha, Dhan & more with full audit.</span>
              </li>
            </ul>
          </div>

          <a
            href="#mission"
            className="mt-6 inline-flex items-center text-sm font-semibold text-indigo-600 hover:text-indigo-700"
          >
            READ MORE
            <svg className="ml-1 h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path d="M12.293 3.293a1 1 0 011.414 0L19 8.586l-5.293 5.293a1 1 0 01-1.414-1.414L15.586 10H3a1 1 0 110-2h12.586l-3.293-3.293a1 1 0 010-1.414z" />
            </svg>
          </a>
        </div>
      </article>

      {/* Card 2 — Values */}
      <article className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        <div className="order-2 lg:order-1 bg-white rounded-2xl ring-1 ring-black/5 shadow-sm p-6 sm:p-8 flex flex-col justify-between">
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-wider text-gray-500">OUR VALUES</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-gray-900">Guiding Principles</h3>
            <p className="text-gray-600 leading-relaxed">
              These principles shape every feature we ship and every incident we review.
            </p>

            <ul className="mt-3 space-y-3 text-gray-700">
              <li>
                <span className="font-semibold">Integrity:</span> clear pricing, truthful PnL, full audit trails.
              </li>
              <li>
                <span className="font-semibold">Client-Obsession:</span> outcomes over vanity metrics; your edges protected.
              </li>
              <li>
                <span className="font-semibold">Reliability:</span> graceful degradation, retries, warm failover.
              </li>
              <li>
                <span className="font-semibold">Performance:</span> low-latency execution with queueing & throttles.
              </li>
              <li>
                <span className="font-semibold">Security & Compliance:</span> least-privilege keys, encrypted secrets, audit.
              </li>
              <li>
                <span className="font-semibold">Open by Default:</span> clean APIs, webhooks, SDKs, and export-everything.
              </li>
            </ul>
          </div>

          <a
            href="#values"
            className="mt-6 inline-flex items-center text-sm font-semibold text-indigo-600 hover:text-indigo-700"
          >
            READ MORE
            <svg className="ml-1 h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path d="M12.293 3.293a1 1 0 011.414 0L19 8.586l-5.293 5.293a1 1 0 01-1.414-1.414L15.586 10H3a1 1 0 110-2h12.586l-3.293-3.293a1 1 0 010-1.414z" />
            </svg>
          </a>
        </div>

        <SlideInImage
          src={rightImage}
          alt="Team collaborating on strategy code"
          direction="right"
          className="order-1 lg:order-2 min-h-[220px]"
        />
      </article>
    </section>
  );
}
