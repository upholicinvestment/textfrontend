export default function GradientOrbs() {
  return (
    <>
      <div className="pointer-events-none absolute -left-20 -top-16 h-80 w-80 rounded-full bg-white/25 blur-3xl" />
      <div className="pointer-events-none absolute -right-24 top-1/3 h-80 w-80 rounded-full bg-white/20 blur-3xl" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-24 w-96 -translate-x-1/2 rounded-full bg-white/10 blur-2xl" />
    </>
  );
}
