import { ComponentType } from "react";

type IconProps = { size?: number; className?: string };
type Props = { Icon: ComponentType<IconProps>; title: string; body: string };

export default function InfoCard({ Icon, title, body }: Props) {
  const GRAD = "from-[#1a237e] to-[#4a56d2]";
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <div className={`mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${GRAD} text-white`}>
        <Icon size={18} />
      </div>
      <div className="font-semibold">{title}</div>
      <p className="mt-1 text-sm text-slate-600">{body}</p>
    </div>
  );
}
