type Props = { year: string; title: string; body: string };

export default function TimelineCard({ year, title, body }: Props) {
  return (
    <div className="w-[320px] shrink-0 snap-center lg:w-auto lg:shrink">
      <div className="relative rounded-[22px] border border-[#3340b71a] bg-white p-6 shadow-[0_18px_40px_-22px_rgba(2,6,23,.35)]">
        <div className="absolute -top-5 left-1/2 -translate-x-1/2 rounded-full bg-[#1a237e] p-2.5 shadow-xl ring-8 ring-white">
          <div className="h-4 w-4 rounded-full bg-[#4a56d2]" />
        </div>
        <div className="text-sm font-semibold text-slate-500">{year}</div>
        <div className="text-lg font-semibold">{title}</div>
        <p className="mt-2 text-sm text-slate-600">{body}</p>
      </div>
    </div>
  );
}
