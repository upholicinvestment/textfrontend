import { ComponentType } from "react";
type IconProps = { size?: number; className?: string };
type Props = { Icon: ComponentType<IconProps>; title: string; body: string; className?: string };

export default function GlassCard({ Icon, title, body, className = "" }: Props) {
  return (
    <div className={`relative h-full rounded-3xl border border-slate-100 bg-white/70 p-6 shadow-[0_12px_30px_-12px_rgba(2,6,23,.15)] backdrop-blur ${className}`}>
      <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-[#1a237e] text-white shadow-lg ring-4 ring-white/60">
        <Icon size={18} />
      </div>
      <div className="text-lg font-semibold">{title}</div>
      <p className="mt-1 text-sm text-slate-600">{body}</p>
    </div>
  );
}
