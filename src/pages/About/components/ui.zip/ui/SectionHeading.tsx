type Props = { title: string; subtitle?: string; badge?: string };

export default function SectionHeading({ title, subtitle, badge = "Upholic Tech" }: Props) {
  const GRAD = "from-[#1a237e] to-[#4a56d2]";
  return (
    <div className="mb-8 text-center">
      <span className={`inline-block rounded-full bg-gradient-to-r ${GRAD} px-3 py-1 text-xs font-semibold text-white`}>
        {badge}
      </span>
      <h2 className="mt-3 text-3xl font-bold md:text-4xl">{title}</h2>
      {subtitle && <p className="mt-2 text-slate-600">{subtitle}</p>}
    </div>
  );
}
