type Props = { title: string; desc: string; button: string; href: string };

export default function CTA({ title, desc, button, href }: Props) {
  const GRAD = "from-[#1a237e] to-[#4a56d2]";
  return (
    <section className="px-6 pb-16 pt-8 md:pb-20">
      <div className={`relative mx-auto max-w-7xl overflow-hidden rounded-[28px] bg-gradient-to-r ${GRAD} p-6 text-white md:p-10`}>
        {/* aurora */}
        <div className="pointer-events-none absolute -top-24 left-1/3 h-64 w-64 rounded-full bg-white/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 right-1/4 h-64 w-64 rounded-full bg-white/20 blur-3xl" />
        <div className="relative grid items-center gap-6 md:grid-cols-[1.6fr_.4fr]">
          <div>
            <div className="text-2xl font-semibold">{title}</div>
            <p className="mt-1 text-white/90">{desc}</p>
          </div>
          <div className="md:text-right">
            <a href={href} className="inline-flex rounded-full bg-white px-6 py-3 font-semibold text-[#1a237e] shadow-lg">
              {button}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
