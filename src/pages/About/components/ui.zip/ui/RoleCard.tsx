type Role = { track: string; title: string; blurb: string; tags: string[] };

export default function RoleCard({ role }: { role: Role }) {
  const GRAD = "from-[#1a237e] to-[#4a56d2]";
  return (
    <div className="rounded-3xl border border-slate-200 p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">{role.track}</div>
          <div className="text-lg font-semibold">{role.title}</div>
          <p className="mt-1 text-sm text-slate-600">{role.blurb}</p>
        </div>
        <a href="mailto:careers@upholic.tech" className={`rounded-full bg-gradient-to-r ${GRAD} px-4 py-2 text-sm font-semibold text-white`}>
          Apply
        </a>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {role.tags.map((t) => (
          <span key={t} className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}
